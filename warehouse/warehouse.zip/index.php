<?php
require_once('db_config.php');
if($user->is_loggedin()!="")
{
	 $user_id = $_SESSION['user_session'];
    $stmt=$DB_con->prepare("SELECT * FROM users_content WHERE email =:ema");
    $stmt->bindParam(":ema",$user_id);
    $stmt->execute();
    $results=$stmt->fetch(PDO::FETCH_ASSOC);
    if($results['email'] =="admin@gmail.com")
    {
        $user->redirect('admin_dashboard.php');
    }
    else
    {
        $user->redirect('user_dashboard.php');
    }
    
}
?>
<!DOTYPE HTML>
    <html lang="en">
      <head>
        <!-- Required meta tags !--->
								<title>WAREHOUSE MANAGEMENT| PORTAL</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
        <link rel="stylesheet" href="bootstrap-4.1.3-dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
             <link type="text/css" rel="stylesheet" href="fontawesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/w3-theme-indigo.css" type="text/css">
<link rel="stylesheet" href="css/w3-colors-metro.css" type="text/css">
<link rel="stylesheet" href="css/w3-colors-flat.css" type="text/css">
<link rel="stylesheet" href="css/animate.css">

	
	<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/w3-colors-windows.css" type="text/css">
<link rel="stylesheet" href="css/w3-colors-safety.css" type="text/css">
<link rel="stylesheet" href="css/w3-colors-highway.css" type="text/css">
<link rel="stylesheet" href="css/flexslider.css">

<link rel="stylesheet" href="css/style.css">
     <link type="text/css" rel="stylesheet" href="css/w3school.css">
        <!-- Compiled and minified CSS -->
  <link rel="stylesheet" href="css/materialize.min.css">

  <!-- Compiled and minified JavaScript -->
      <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>

      <script type="text/javascript" src="js/materialize.min.js"></script>
      <script type="text/javascript">
				$(document).ready(function(){
					//alert("YOU ARE GOOD TO GO");
					                $("#loginForm").on('submit',(function(e)
																{
																	e.preventDefault();
																	$.ajax({
																		url:"logged.php",
																		type:"POST",
																		data:new FormData(this),
																		contentType:false,
																		cache:false,
																		processData:false,
																		beforeSend: function(){	
				$("#error").fadeOut();
				$("#login_button").html('<span class="glyphicon glyphicon-transfer"></span> &nbsp; Checking Credentials ...');
			},
																		success:function(data)
																		{
																			//$("#return-data").html(data);
																			if (data=="OK") {
                                                                                //code
																				 $("#login_button").html('<img src="img/ajax-loader.gif" /> &nbsp; Signing In ...');
					setTimeout(' window.location.href = "choose_dashboard.php"; ',3000);
                                                }
																		else {									
					$("#error").fadeIn(1000, function(){						
						$("#error").html('<div class="alert alert-danger alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <span class="glyphicon glyphicon-info-sign"></span> &nbsp; '+data+' !</div>');
						$("#login_button").html('<span class="glyphicon glyphicon-log-in"></span> &nbsp; Sign In');
					});
				}
																		}
																		
																	
																	});
				}));
				});
			</script>
      </head>
      <body>
        <header class="w3-card-4 w3-padding-16 w3-blue">
          <h3 class="w3-text-black w3-center w3-bottombar" style="font-family: cursive;">GLOBAL LOGISTICS LIMITED</h3>
          <h6 class="w3-center"><i>Warehouse Management and Reservation System</i></h6>
        </header>
        <div class="row w3-padding-16 w3-padding-right w3-padding-left w3-card-4">
            <div class="w3-padding-32 col-sm-6 col-md-6 col-lg-6">
                <ul class="w3-ul w3-padding-left" style="list-style: none;" >
                    <li>About Our Company </li>
                    <li>Global Logistics Limited was started in 2016 with one warehouse location in Nairobi.<br>
					It has since grown to be a major player in the warehousing industry today with numerous locations around the country.</li>
                    
                </ul>
            </div>
             <div class="w3-padding-32 col-sm-6 col-md-6 col-lg-6">
                <div class="row">
                    <div class="col-sm-4 col-lg-4 col-md-4">
                        
                    </div>

                 <div class="col-sm-8 col-lg-8 col-md-8">
 <!--<img  class="img-circle" src="img/img_avatar14.pn">

                    </div>
                </div> -->
                <form method="POST" id="loginForm">
                    <form id="formName" action="" method="POST">
                            <div id="error"></div>
                            <div class="input-field ">
                            <input type="text" name="user" class="">
                            <label for="user" class="">Email</label>
                            </div>
                            <div class="input-field">
                            <input type="password" class="" name="password">
                            <label for="password">Password</label>
                            </div>
                            <div class="w3-padding-16" id="btlogin"></div>
                            <button id="login_button" type="submit" class="btn btn-lg btn-block btn-success">LOGIN</button>
                       
                    
                </form>
            </div>
        </div>
      </body>
    </html>